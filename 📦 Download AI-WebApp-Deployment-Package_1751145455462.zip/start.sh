#!/bin/bash
echo "🚀 Starting deployment..."
docker compose down
docker compose up --build -d
echo "✅ App deployed at http://<your-vps-ip>"

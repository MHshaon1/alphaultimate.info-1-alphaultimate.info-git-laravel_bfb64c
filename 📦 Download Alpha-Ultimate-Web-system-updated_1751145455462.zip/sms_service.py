import os
import logging
from twilio.rest import Client

logger = logging.getLogger(__name__)

class SMSService:
    def __init__(self):
        self.account_sid = os.environ.get("TWILIO_ACCOUNT_SID")
        self.auth_token = os.environ.get("TWILIO_AUTH_TOKEN")
        self.phone_number = os.environ.get("TWILIO_PHONE_NUMBER")
        
        if self.account_sid and self.auth_token and self.phone_number:
            self.client = Client(self.account_sid, self.auth_token)
            self.enabled = True
        else:
            self.client = None
            self.enabled = False
            logger.warning("Twilio credentials not found. SMS functionality disabled.")
    
    def send_sms(self, to_phone_number, message):
        """Send SMS message to a phone number"""
        if not self.enabled or not self.client:
            logger.error("SMS service is not enabled. Check Twilio credentials.")
            return False
        
        try:
            sms_message = self.client.messages.create(
                body=message,
                from_=self.phone_number,
                to=to_phone_number
            )
            logger.info(f"SMS sent successfully. SID: {sms_message.sid}")
            return True
        except Exception as e:
            logger.error(f"Failed to send SMS: {str(e)}")
            return False
    
    def send_approval_notification(self, phone_number, request_type, status):
        """Send approval notification SMS"""
        message = f"Your {request_type} request has been {status.lower()}. Check your dashboard for details."
        return self.send_sms(phone_number, message)
    
    def send_admin_alert(self, admin_phone, request_type, submitter_name):
        """Send alert to admin about new request"""
        message = f"New {request_type} request submitted by {submitter_name}. Review required."
        return self.send_sms(admin_phone, message)

# Initialize SMS service
sms_service = SMSService()
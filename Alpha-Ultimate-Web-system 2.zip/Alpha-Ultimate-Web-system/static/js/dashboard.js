// Alpha Ultimate Workdesk - Dashboard Analytics
// Chart.js configuration and dashboard functionality

let monthlyTrendsChart = null;
let statusDistributionChart = null;
let departmentChart = null;

// Chart.js default configuration
Chart.defaults.color = '#B0B0B0';
Chart.defaults.borderColor = '#404040';
Chart.defaults.backgroundColor = 'rgba(0, 212, 170, 0.1)';

// Color palette
const colors = {
    primary: '#00D4AA',
    success: '#00C851',
    warning: '#FFB347',
    danger: '#FF4444',
    info: '#33B5E5',
    secondary: '#B0B0B0',
    dark: '#2D2D2D'
};

function initializeDashboard(stats) {
    // Initialize charts with placeholder data
    initializeMonthlyTrends();
    initializeStatusDistribution();
    initializeDepartmentChart();
    
    // Animate metric cards
    animateMetrics();
}

function initializeMonthlyTrends() {
    const ctx = document.getElementById('monthlyTrendsChart');
    if (!ctx) return;

    monthlyTrendsChart = new Chart(ctx, {
        type: 'line',
        data: {
            labels: [],
            datasets: [
                {
                    label: 'Purchase Requests',
                    data: [],
                    borderColor: colors.primary,
                    backgroundColor: 'rgba(0, 212, 170, 0.1)',
                    borderWidth: 3,
                    fill: true,
                    tension: 0.4,
                    pointBackgroundColor: colors.primary,
                    pointBorderColor: colors.primary,
                    pointRadius: 6,
                    pointHoverRadius: 8
                },
                {
                    label: 'Cash Demands',
                    data: [],
                    borderColor: colors.warning,
                    backgroundColor: 'rgba(255, 179, 71, 0.1)',
                    borderWidth: 3,
                    fill: true,
                    tension: 0.4,
                    pointBackgroundColor: colors.warning,
                    pointBorderColor: colors.warning,
                    pointRadius: 6,
                    pointHoverRadius: 8
                }
            ]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    position: 'top',
                    labels: {
                        usePointStyle: true,
                        padding: 20,
                        font: {
                            size: 12,
                            weight: '600'
                        }
                    }
                },
                tooltip: {
                    backgroundColor: '#2D2D2D',
                    titleColor: '#FFFFFF',
                    bodyColor: '#B0B0B0',
                    borderColor: '#404040',
                    borderWidth: 1,
                    cornerRadius: 8,
                    padding: 12
                }
            },
            scales: {
                x: {
                    grid: {
                        color: '#404040',
                        drawBorder: false
                    },
                    ticks: {
                        color: '#B0B0B0',
                        font: {
                            size: 11
                        }
                    }
                },
                y: {
                    beginAtZero: true,
                    grid: {
                        color: '#404040',
                        drawBorder: false
                    },
                    ticks: {
                        color: '#B0B0B0',
                        font: {
                            size: 11
                        }
                    }
                }
            },
            interaction: {
                intersect: false,
                mode: 'index'
            }
        }
    });
}

function initializeStatusDistribution() {
    const ctx = document.getElementById('statusDistributionChart');
    if (!ctx) return;

    statusDistributionChart = new Chart(ctx, {
        type: 'doughnut',
        data: {
            labels: ['Pending', 'Approved', 'Rejected'],
            datasets: [{
                data: [0, 0, 0],
                backgroundColor: [
                    colors.warning,
                    colors.success,
                    colors.danger
                ],
                borderColor: '#1A1A1A',
                borderWidth: 3,
                hoverOffset: 8
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    position: 'bottom',
                    labels: {
                        usePointStyle: true,
                        padding: 15,
                        font: {
                            size: 12,
                            weight: '600'
                        }
                    }
                },
                tooltip: {
                    backgroundColor: '#2D2D2D',
                    titleColor: '#FFFFFF',
                    bodyColor: '#B0B0B0',
                    borderColor: '#404040',
                    borderWidth: 1,
                    cornerRadius: 8,
                    padding: 12,
                    callbacks: {
                        label: function(context) {
                            const total = context.dataset.data.reduce((a, b) => a + b, 0);
                            const percentage = total > 0 ? ((context.parsed / total) * 100).toFixed(1) : 0;
                            return `${context.label}: ${context.parsed} (${percentage}%)`;
                        }
                    }
                }
            },
            cutout: '60%'
        }
    });
}

function initializeDepartmentChart() {
    const ctx = document.getElementById('departmentChart');
    if (!ctx) return;

    departmentChart = new Chart(ctx, {
        type: 'bar',
        data: {
            labels: ['Finance', 'HR', 'IT', 'Marketing', 'Operations', 'Sales', 'Legal', 'Admin'],
            datasets: [{
                label: 'Requests',
                data: [0, 0, 0, 0, 0, 0, 0, 0],
                backgroundColor: [
                    colors.primary,
                    colors.success,
                    colors.info,
                    colors.warning,
                    colors.danger,
                    colors.secondary,
                    '#9C27B0',
                    '#FF9800'
                ],
                borderColor: '#1A1A1A',
                borderWidth: 1,
                borderRadius: 6,
                borderSkipped: false
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    display: false
                },
                tooltip: {
                    backgroundColor: '#2D2D2D',
                    titleColor: '#FFFFFF',
                    bodyColor: '#B0B0B0',
                    borderColor: '#404040',
                    borderWidth: 1,
                    cornerRadius: 8,
                    padding: 12
                }
            },
            scales: {
                x: {
                    grid: {
                        display: false
                    },
                    ticks: {
                        color: '#B0B0B0',
                        font: {
                            size: 11
                        },
                        maxRotation: 45
                    }
                },
                y: {
                    beginAtZero: true,
                    grid: {
                        color: '#404040',
                        drawBorder: false
                    },
                    ticks: {
                        color: '#B0B0B0',
                        font: {
                            size: 11
                        },
                        stepSize: 1
                    }
                }
            }
        }
    });
}

function updateCharts(data) {
    if (!data) return;

    // Update status distribution
    updateStatusDistribution(data);
    
    // Update monthly trends
    updateMonthlyTrends(data);
    
    // Update department chart
    updateDepartmentChart(data);
}

function updateStatusDistribution(data) {
    if (!statusDistributionChart || !data.purchase_status || !data.demand_status) return;

    const totalPending = (data.purchase_status.Pending || 0) + (data.demand_status.Pending || 0);
    const totalApproved = (data.purchase_status.Approved || 0) + (data.demand_status.Approved || 0);
    const totalRejected = (data.purchase_status.Rejected || 0) + (data.demand_status.Rejected || 0);

    statusDistributionChart.data.datasets[0].data = [totalPending, totalApproved, totalRejected];
    statusDistributionChart.update('active');
}

function updateMonthlyTrends(data) {
    if (!monthlyTrendsChart || !data.monthly_data) return;

    const monthlyData = data.monthly_data;
    const sortedMonths = Object.keys(monthlyData).sort();
    
    // Get last 6 months of data
    const recentMonths = sortedMonths.slice(-6);
    
    const labels = recentMonths.map(month => {
        const date = new Date(month + '-01');
        return date.toLocaleDateString('en-US', { month: 'short', year: 'numeric' });
    });
    
    const purchaseData = recentMonths.map(month => monthlyData[month]?.purchases || 0);
    const demandData = recentMonths.map(month => monthlyData[month]?.demands || 0);

    monthlyTrendsChart.data.labels = labels;
    monthlyTrendsChart.data.datasets[0].data = purchaseData;
    monthlyTrendsChart.data.datasets[1].data = demandData;
    monthlyTrendsChart.update('active');
}

function updateDepartmentChart(data) {
    if (!departmentChart) return;

    // For now, just use random data as we don't have department breakdown in the API
    // In a real implementation, this would come from the backend
    const departments = ['Finance', 'HR', 'IT', 'Marketing', 'Operations', 'Sales', 'Legal', 'Admin'];
    const departmentData = departments.map(() => Math.floor(Math.random() * 10));

    departmentChart.data.datasets[0].data = departmentData;
    departmentChart.update('active');
}

function animateMetrics() {
    const metricCards = document.querySelectorAll('.metric-card');
    
    metricCards.forEach((card, index) => {
        setTimeout(() => {
            card.style.opacity = '0';
            card.style.transform = 'translateY(20px)';
            
            requestAnimationFrame(() => {
                card.style.transition = 'all 0.6s ease';
                card.style.opacity = '1';
                card.style.transform = 'translateY(0)';
            });
        }, index * 100);
    });
}

// Utility function to format currency
function formatCurrency(amount) {
    return new Intl.NumberFormat('en-US', {
        style: 'currency',
        currency: 'USD',
        minimumFractionDigits: 0,
        maximumFractionDigits: 0
    }).format(amount);
}

// Utility function to format numbers
function formatNumber(num) {
    if (num >= 1000000) {
        return (num / 1000000).toFixed(1) + 'M';
    } else if (num >= 1000) {
        return (num / 1000).toFixed(1) + 'K';
    }
    return num.toString();
}

// Auto-refresh dashboard data every 5 minutes
setInterval(() => {
    fetch('/api/dashboard-data')
        .then(response => response.json())
        .then(data => {
            updateCharts(data);
        })
        .catch(error => {
            console.error('Error refreshing dashboard data:', error);
        });
}, 300000); // 5 minutes

// Handle chart responsiveness
window.addEventListener('resize', () => {
    if (monthlyTrendsChart) monthlyTrendsChart.resize();
    if (statusDistributionChart) statusDistributionChart.resize();
    if (departmentChart) departmentChart.resize();
});

// Export functions for global access
window.dashboardUtils = {
    initializeDashboard,
    updateCharts,
    formatCurrency,
    formatNumber
};
